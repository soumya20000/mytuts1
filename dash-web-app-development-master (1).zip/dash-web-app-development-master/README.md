# dash-web-app-development

Repo for DSO-BTC dash workshop.
![AppInterface](App.png)