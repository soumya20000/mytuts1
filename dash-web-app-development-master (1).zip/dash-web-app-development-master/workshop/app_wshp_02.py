import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate

import plotly.graph_objects as go
import plotly.figure_factory as ff



from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score
# import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import pickle




app = dash.Dash(__name__)
app_color = {"graph_bg": '#1a1b1d', "graph_bg1": "#222629", "graph_line": "#86C232", 'heading': '#86C232'}

app.layout = html.Div(
    ######## This Div is the main comntainer of all the dash and html components; following list contains all its children
    [
        html.Div(
            ####### This is the App Header Div, contains title and description
            [
                
                html.H4("WINE CLASSIFICATION", 
                
                style = {'color' : 'white', 'font-size': '30px', 'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                ),
                html.P(
                    "Exploratory Data Analysis and Random Forest Classification Modeling of Wines",
                    style = {'color': app_color['heading'], 'font-size': '15px', 'padding': '0px 0px 0px 0px', 'margin': '5px 0px 0px 0px'}
                   
                ),
                 
                
            ],
            
            
        
        ),
        html.Div(
            #######this will contain two panes of equal width , aligned horizontally, 1st for EDA, 2nd for ML
            [
                html.Div(
                    ########this will have two panes aligned vertically, top: Histogram, bot: X-plot
                    [
                        html.Div(
                                [
                                    html.H5('Exploratory Data Analysis')
                                ],
                                style = {'color' : 'white',  'text-align': 'center',  'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                        ),

                       
                    ],
                    className = 'six columns',
                    style = {'margin': '0px 10px 0px 0px'}


                ),

                html.Div(
                    ######## This will have four panes aligned vertically, 1st: Model training params, 2nd: feature importance, 3rd: ROC, 4th: User Prediction
                    [
                        html.Div(
                            [
                                html.H5('Classification using Random Forest')
                            ],
                            style = {'color' : 'white',  'text-align': 'center',  'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                        ),
                        
                        

                    ],
                    className = 'six columns',
                    style = {'margin': '0px 0px 0px 10px'}

                )

            ],
            className="rows",
            style = {'display': 'flex', 'margin-top': '20px'}
        )

    ],
    # className="app__container",
    style = { 'margin': '3% 5%'}

)




if __name__ == "__main__":
    app.run_server(debug=True)