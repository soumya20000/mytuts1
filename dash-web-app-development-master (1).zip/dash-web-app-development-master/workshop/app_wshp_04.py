import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate

import plotly.graph_objects as go
import plotly.figure_factory as ff



from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score
# import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import pickle


###############################################################################################################
## Loading Wine data from scikit-learn and dataframe creation
data = load_wine()
df = pd.DataFrame(
    data=np.concatenate((data['data'], np.reshape(data['target'], (data['target'].shape[0],1))), axis = 1),  
    columns=data['feature_names']+['WineClass']
    )
###############################################################################################################

app = dash.Dash(__name__)
app_color = {"graph_bg": '#1a1b1d', "graph_bg1": "#222629", "graph_line": "#86C232", 'heading': '#86C232'}

app.layout = html.Div(
    ######## This Div is the main comntainer of all the dash and html components; following list contains all its children
    [
        html.Div(
            ####### This is the App Header Div, contains title and description
            [
                
                html.H4("WINE CLASSIFICATION", 
                # className="app__header__title"
                style = {'color' : 'white', 'font-size': '30px', 'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                ),
                html.P(
                    "Exploratory Data Analysis and Random Forest Classification Modeling of Wines",
                    style = {'color': app_color['heading'], 'font-size': '15px', 'padding': '0px 0px 0px 0px', 'margin': '5px 0px 0px 0px'}
                    # className="app__header__title--grey",
                ),
                 
                
            ],
            # className="app__header",
            
        
        ),
        html.Div(
            #######this will contain two panes of equal width , aligned horizontally, 1st for EDA, 2nd for ML
            [
                html.Div(
                    ########this will have two panes aligned vertically, top: Histogram, bot: X-plot
                    [
                        html.Div(
                                [
                                    html.H5('Exploratory Data Analysis')
                                ],
                                style = {'color' : 'white',  'text-align': 'center',  'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                        ),

                        html.Div(
                            ######### Histogram
                            [
                                html.Div(
                                    [
                                        html.H6('Feature Distribution',
                                        style = {'color' : 'gray', 'font-size': '17px', 'margin': '10px 0px 0px 20px'}),

                                    ],
                                    style = {'margin': '0px 20px 10px 0px'}
                                    
                                ),
                                html.Div(
                                    [
                                        dcc.Dropdown(
                                            id = 'feat-drpdn',
                                            options=[{'label': df.columns[:-1][i], 'value': i} for i in range(len(df.columns[:-1]))],
                                            value = 0,
                                            style = {'width': '55%', 'margin': '0px 0px 0px 10px','background-color': app_color["graph_bg"]}
                                        ),
                                    ]
                                ),
                                

                                dcc.Graph(
                                    id="feat-histogram",
                                    figure=dict(
                                        layout=dict(
                                            plot_bgcolor=app_color["graph_bg"],
                                            paper_bgcolor=app_color["graph_bg"],
                                        )
                                    ),
                                    
                                ),
                            ],
                            style = {'display': 'flex', 'flex-direction': 'column', 'background-color': app_color["graph_bg"], 'margin': '0px 0px 10px 0px'}
                        ),
                        html.Div(
                            [
                               html.Div(
                                    [
                                        html.H6('Feature Correlation',
                                        style = {'color' : 'gray', 'font-size': '17px', 'margin': '10px 0px 0px 20px'}),

                                    ],
                                    style = {'margin': '0px 20px 10px 0px'}
                                    
                                ),

                                html.Div(
                                    ######## This Div Contains two dropdowns for feature selection for x-plot
                                    [
                                        html.Div(
                                            dcc.Dropdown(
                                            id = 'feat-xplot-1',
                                            options=[{'label': df.columns[:-1][i], 'value': i} for i in range(len(df.columns[:-1]))],
                                            value = 0,
                                            style = {'margin': '0px 0px 0px 10px', 'background-color': app_color["graph_bg"]}
                                            ),
                                            className = 'six columns'
                                        ),
                                        html.Div(
                                            dcc.Dropdown(
                                            id = 'feat-xplot-2',
                                            options=[{'label': df.columns[:-1][i], 'value': i} for i in range(len(df.columns[:-1]))],
                                            value = len(df.columns[:-1])-1,
                                            style = {'margin': '0px 10px 0px 0px', 'background-color': app_color["graph_bg"]}
                                            ),
                                            className = 'six columns'
                                        )
                                        
                                    ],
                                    className = 'row'
                                ),
                                dcc.Graph(
                                    id="feat-xplot",
                                    figure=dict(
                                        layout=dict(
                                            plot_bgcolor=app_color["graph_bg"],
                                            paper_bgcolor=app_color["graph_bg"],
                                        )
                                    ),
                                    
                                ),  
                            ],
                            style = {'display': 'flex', 'flex-direction': 'column', 'background-color': app_color["graph_bg"], 'margin': '10px 0px 0px 0px'}
                        )
                    ],
                    className = 'six columns',
                    style = {'margin': '0px 10px 0px 0px'}


                ),

                html.Div(
                    ######## This will have four panes aligned vertically, 1st: Model training params, 2nd: feature importance, 3rd: ROC, 4th: User Prediction
                    [
                        html.Div(
                            [
                                html.H5('Classification using Random Forest')
                            ],
                            style = {'color' : 'white',  'text-align': 'center',  'padding': '0px 0px 0px 0px', 'margin': '0px 0px 0px 0px'}
                        ),
                        
                        

                    ],
                    className = 'six columns',
                    style = {'margin': '0px 0px 0px 10px'}

                )

            ],
            className="rows",
            style = {'display': 'flex', 'margin-top': '20px'}
        )

    ],
    # className="app__container",
    style = { 'margin': '3% 5%'}

)



@app.callback(
    Output(component_id='feat-histogram', component_property='figure'),
    [Input(component_id='feat-drpdn', component_property='value')]
)
def update_feat_histogram(input_value):
    
    ft_max, ft_min = max(df.iloc[:,input_value]), min(df.iloc[:,input_value])
    bin_size = (ft_max-ft_min)/30
    hist_data = [df[df['WineClass']==wine_cls].iloc[:,input_value] for wine_cls in df['WineClass'].unique()]

    group_labels = ['Class 1', 'Class 2', 'Class 3']
    colors = ['rgb(77,92,56)','rgb(112, 155,51)','rgb(150, 253, 5)']

    # Create distplot with curve_type set to 'normal'
    fig = ff.create_distplot(
        hist_data, 
        group_labels, 
        colors=colors, 
        bin_size=bin_size, 
        show_rug=False)
    

    fig.update_layout(
        barmode='stack',
        height=360,
        plot_bgcolor=app_color["graph_bg"],
        paper_bgcolor=app_color["graph_bg"],
        font={"color": "#fff"},
        xaxis={
            "title": df.columns[input_value],
            "showgrid": False,
            "showline": False,
            "fixedrange": True,
        },
        yaxis={
            "showgrid": False,
            "showline": False,
            "zeroline": False,
            "title": "Number of Samples",
            "fixedrange": True,
        },
        autosize=True,
        )
    # Reduce opacity to see both histograms
    fig.update_traces(opacity=0.75)

    return fig

@app.callback(
    Output(component_id='feat-xplot', component_property='figure'),
    [Input(component_id='feat-xplot-1', component_property='value'),
    Input(component_id='feat-xplot-2', component_property='value')]
)
def update_features_xplot(ft1, ft2):
    fig = go.Figure()
    colors = ['rgb(77,92,56)','rgb(112, 155,51)','rgb(150, 253, 5)']
    sizes = [5,8,11]

    for i, wine_cls in enumerate(df['WineClass'].unique()):
        fig.add_trace(go.Scatter(
                    x=df[df['WineClass']==wine_cls].iloc[:,ft1], 
                    y=df[df['WineClass']==wine_cls].iloc[:,ft2],
                    mode='markers',
                    marker_color=colors[i],
                    marker_size=sizes[i],
                    marker_line_color='white',
                    marker_line_width = 1,
                    name = 'Class {}'.format(i+1)
                    )
        )
    
    fig.update_layout(
        height=360,
        plot_bgcolor=app_color["graph_bg"],
        paper_bgcolor=app_color["graph_bg"],
        font={"color": "#fff"},
        xaxis={
            "title": df.columns[ft1],
            "showgrid": False,
            "showline": False,
            "fixedrange": True,
        },
        yaxis={
            "showgrid": False,
            "showline": False,
            "zeroline": False,
            "title": df.columns[ft2],
            "fixedrange": True,
        },
        autosize=True,
        )
    return fig
    




if __name__ == "__main__":
    app.run_server(debug=True)