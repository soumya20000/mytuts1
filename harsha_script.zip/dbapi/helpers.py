import pyodbc
import pandas as pd


def get_connection(filename: str):
    conn = None
    try:
        drivername = r"Microsoft Access Driver (*.mdb, *.accdb)"
        conn = pyodbc.connect(f'Driver={{{drivername}}};DBQ={filename};')
    except Exception as e:
        print(e)
    finally:
        return conn


def execute_query(query: str, filename: str):
    conn = get_connection(filename)
    df = pd.DataFrame()
    if conn:
        try:
            print(f"Executing the query ...")
            df = pd.read_sql_query(sql=query, con=conn)
        except Exception as e:
            print(e)
        finally:
            conn.close()
    return df
