import pandas as pd
from dbapi.helpers import execute_query
from path import Path
from typing import Union
import os


def extract(query_file_path: Union[str, Path], db_abs_file_path: Union[str, Path]) -> pd.DataFrame:
    """

    :param query_file_path:
    :param db_abs_file_path:
    :return:
    """
    with open(query_file_path, "r") as query_reader:
        query = query_reader.read()
        query = query.strip()
    print(f"Reading db file {db_abs_file_path.basename()}")
    df = execute_query(query, db_abs_file_path)
    return df


def extract_all(query_file_path: Union[str, Path], db_folder: Union[str, Path])->pd.DataFrame:
    """

    :param query_file_path:
    :param db_folder:
    :return:
    """
    db_folder = Path(db_folder).abspath()
    all_dfs = []
    master_df = pd.DataFrame()
    for root, dirs, files in os.walk(db_folder):
        for file in files:
            if file.endswith(".mdb") or file.endswith(".accdb"):
                db_abs_path = db_folder/file
                print(db_abs_path)
                df = extract(query_file_path, db_abs_path)
                if not df.empty:
                    df['dbName'] = Path(file).stem
                    all_dfs.append(df)
    if len(all_dfs) > 0:
        master_df = pd.concat(all_dfs, axis=0, ignore_index=True)
    return master_df