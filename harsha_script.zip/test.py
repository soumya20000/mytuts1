import pandas as pd
import pyodbc
def test_raw_driver():
    conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=D:\TFS\DownstreamDataProject\dbs\PESTRA3.0_S4_JUR OMS_Fixed_Master.accdb;')
    cursor = conn.cursor()
    cursor.execute('select EquipTag from Equip;')
    print("Print a couple of rows")
    i = 0
    for row in cursor.fetchall():
        print (i,row)
        i = i + 1
        if(i> 10):
            break
    conn.close()

def test_pandas():
    conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=D:\TFS\DownstreamDataProject\dbs\PESTRA3.0_S4_JUR OMS_Fixed_Master.accdb;')
    df = pd.read_sql_query(sql="select EquipTag from Equip;",con=conn)
    conn.close()
    print(df)
if __name__ == "__main__":
    # test_raw_driver()
    test_pandas()
