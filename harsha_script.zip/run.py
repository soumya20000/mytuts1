import datetime
from path import Path
from extractapi.extract import extract_all


if __name__ == "__main__":
    queryfile = Path(r"./queries/Query_2.txt")
    db_folder = Path(r"./dbs")
    output_folder = Path(r"./output")
    master_df = extract_all(queryfile, db_folder)
    print(master_df)
    print(master_df.dbName.unique())
    output_file = output_folder/f"output{datetime.datetime.now()}.csv"
    # print(f"Writing the output to {output_file}")
    with open("test.csv", "w", encoding="utf-8") as writer:
        master_df.to_csv(writer)


